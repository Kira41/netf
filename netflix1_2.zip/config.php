<?php 

// This example page was made by @sojecdiv
// Telegram me: https://t.me/sojecdiv
// Don't use this example in any illegal use!


$bot = "8401540353:AAELVHgfvFGozS_kIEuBd6TWFVhTQRVKedk";
$chat_id = "7731970548";


// use antibot? yes|no
$antibot = "yes";

// want to block all VPNs/PROXIES? yes|no
$block_proxy = "no";




?>