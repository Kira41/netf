<?php

header("Location: https://www.netflix.com/");

?>